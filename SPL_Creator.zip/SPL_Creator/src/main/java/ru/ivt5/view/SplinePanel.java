package ru.ivt5.view;

import processing.core.PApplet;
import ru.ivt5.model.Spline;

public class SplinePanel {
    private PApplet app;
    private int x, y, width, height;
    private Spline activeSpline;
    private UIControls uiControls;

    public SplinePanel(PApplet app, int x, int y, int width, int height, UIControls uiControls) {
        this.app = app;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.uiControls = uiControls;
    }

    public void setActiveSpline(Spline spline) {
        this.activeSpline = spline;
    }

    public void draw() {
        if (activeSpline == null) return;

        app.pushMatrix();
        app.translate(x, y);
        app.noFill();
        app.stroke(200);
        app.rect(0, 0, width, height); // рамка панели

        // Рисуем сплайн внутри панели
        app.pushStyle();
        app.clip(0, 0, width, height); // ограничиваем рисование рамкой
        activeSpline.draw(app);

        // Показываем касательные, если включено
        if (uiControls != null && uiControls.isTangentsShown()) {
            activeSpline.drawTangents(app);
        }

        // Показываем кривизну, если включено
        if (uiControls != null && uiControls.isCurvatureShown()) {
            activeSpline.drawCurvature(app);
        }

        app.popStyle();

        app.popMatrix();
    }

    // Обработка клика мыши: добавление/выбор/удаление точек
    public void mousePressed() {
        if (activeSpline == null) return;
        if (!isInside(app.mouseX, app.mouseY)) return;

        float localX = app.mouseX - x;
        float localY = app.mouseY - y;

        if (app.mouseButton == PApplet.LEFT) {
            activeSpline.selectPoint(localX, localY);
            if (!activeSpline.hasSelectedPoint()) {
                activeSpline.addPoint(new processing.core.PVector(localX, localY));
            }
        } else if (app.mouseButton == PApplet.RIGHT) {
            activeSpline.removePoint(localX, localY);
        }
    }

    public void mouseDragged() {
        if (activeSpline == null) return;
        if (!isInside(app.mouseX, app.mouseY)) return;

        float localX = app.mouseX - x;
        float localY = app.mouseY - y;

        activeSpline.dragSelectedPoint(localX, localY);
    }

    public void mouseReleased() {
        if (activeSpline == null) return;
        activeSpline.releaseSelectedPoint();
    }

    private boolean isInside(float px, float py) {
        return px >= x && px <= x + width && py >= y && py <= y + height;
    }
}
