package ru.ivt5.view;

import g4p_controls.*;
import processing.core.PApplet;
import ru.ivt5.model.*;
import java.awt.Font;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import processing.core.PVector;

public class UIControls {
    private PApplet app;
    private int x, y, width, height;

    private GDropList splineSelector;
    private GButton clearButton;
    private GButton thinButton, thickButton, colorButton;
    private GCheckbox showTangentsCheckbox;
    private GCheckbox showCurvatureCheckbox;

    private C0Spline c0Spline;
    private C1Spline c1Spline;
    private C2Spline c2Spline;

    private Spline activeSpline;

    private GButton saveButton, loadButton;


    public interface SplineChangeListener {
        void onSplineChanged(Spline newSpline);
    }
    private SplineChangeListener listener;

    public UIControls(PApplet app, int x, int y, int width, int height) {
        this.app = app;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        initControls();
    }

    private void initControls() {
        int padding = 10;
        int btnWidth = width - 2 * padding;
        int btnHeight = 40;  // увеличить высоту элементов
        int yPos = padding;

        Font awtBoldFont = new Font("Arial", Font.BOLD, 16); // тута цифра - это размер шрифта

        splineSelector = new GDropList(app, x + padding, yPos, btnWidth, btnHeight, 3);
        splineSelector.setItems(new String[]{"C0", "C1", "C2"}, 0);
        splineSelector.addEventHandler(this, "handleSplineSelection");
        splineSelector.setLocalColorScheme(G4P.CYAN_SCHEME);
        splineSelector.setFont(awtBoldFont);
        yPos += btnHeight + 10;

        clearButton = new GButton(app, x + padding, yPos, btnWidth, btnHeight);
        clearButton.setText("Очистить");
        clearButton.addEventHandler(this, "handleClearClick");
        clearButton.setLocalColorScheme(G4P.CYAN_SCHEME);
        clearButton.setFont(awtBoldFont);
        yPos += btnHeight + 10;

        thinButton = new GButton(app, x + padding, yPos, btnWidth, btnHeight);
        thinButton.setText("Тонкая");
        thinButton.addEventHandler(this, "handleThinClick");
        thinButton.setLocalColorScheme(G4P.CYAN_SCHEME);
        thinButton.setFont(awtBoldFont);
        yPos += btnHeight + 10;

        thickButton = new GButton(app, x + padding, yPos, btnWidth, btnHeight);
        thickButton.setText("Жирная");
        thickButton.addEventHandler(this, "handleThickClick");
        thickButton.setLocalColorScheme(G4P.CYAN_SCHEME);
        thickButton.setFont(awtBoldFont);
        yPos += btnHeight + 10;

        colorButton = new GButton(app, x + padding, yPos, btnWidth, btnHeight);
        colorButton.setText("Выбрать цвет");
        colorButton.addEventHandler(this, "handleColorClick");
        colorButton.setLocalColorScheme(G4P.CYAN_SCHEME);
        colorButton.setFont(awtBoldFont);
        yPos += btnHeight + 10;

        saveButton = new GButton(app, x + padding, yPos, btnWidth, btnHeight);
        saveButton.setText("Сохранить точки");
        saveButton.addEventHandler(this, "handleSaveClick");
        saveButton.setLocalColorScheme(G4P.CYAN_SCHEME);
        saveButton.setFont(awtBoldFont);
        yPos += btnHeight + 10;

        loadButton = new GButton(app, x + padding, yPos, btnWidth, btnHeight);
        loadButton.setText("Загрузить точки");
        loadButton.addEventHandler(this, "handleLoadClick");
        loadButton.setLocalColorScheme(G4P.CYAN_SCHEME);
        loadButton.setFont(awtBoldFont);
        yPos += btnHeight + 10;


        showTangentsCheckbox = new GCheckbox(app, x + padding, yPos, btnWidth, 30);
        showTangentsCheckbox.setText("Показать касательные");
        showTangentsCheckbox.addEventHandler(this, "handleTangentsToggle");
        showTangentsCheckbox.setLocalColorScheme(G4P.CYAN_SCHEME);
        showTangentsCheckbox.setFont(awtBoldFont);
        yPos += 30;

        showCurvatureCheckbox = new GCheckbox(app, x + padding, yPos, btnWidth, 30);
        showCurvatureCheckbox.setText("Показать кривизну");
        showCurvatureCheckbox.addEventHandler(this, "handleCurvatureToggle");
        showCurvatureCheckbox.setLocalColorScheme(G4P.CYAN_SCHEME);
        showCurvatureCheckbox.setFont(awtBoldFont);
    }


    public void setSplines(C0Spline c0, C1Spline c1, C2Spline c2) {
        this.c0Spline = c0;
        this.c1Spline = c1;
        this.c2Spline = c2;
    }

    public void setActiveSpline(Spline spline) {
        this.activeSpline = spline;
        updateSelectorBySpline(spline);
        updateCheckboxes();
    }

    private void updateSelectorBySpline(Spline spline) {
        if (spline == c0Spline) splineSelector.setSelected(0);
        else if (spline == c1Spline) splineSelector.setSelected(1);
        else if (spline == c2Spline) splineSelector.setSelected(2);
    }

    private void updateCheckboxes() {
        showTangentsCheckbox.setSelected(activeSpline.isShowTangents());
        showCurvatureCheckbox.setSelected(activeSpline.isShowCurvature());
    }

    public void setSplineChangeListener(SplineChangeListener listener) {
        this.listener = listener;
    }

    public void draw() {
        app.pushStyle();
        app.fill(90);  // светлее фон панели делаем тут
        app.noStroke();
        app.rect(x, y, width, height);
        app.popStyle();

        saveButton.draw();
        loadButton.draw();


        splineSelector.draw();
        clearButton.draw();
        thinButton.draw();
        thickButton.draw();
        colorButton.draw();
        showTangentsCheckbox.draw();
        showCurvatureCheckbox.draw();
    }

    public void handleSplineSelection(GDropList source, GEvent event) {
        if (event == GEvent.SELECTED) {
            String sel = source.getSelectedText();
            Spline newSpline = switch (sel) {
                case "C0" -> c0Spline;
                case "C1" -> c1Spline;
                case "C2" -> c2Spline;
                default -> activeSpline;
            };
            activeSpline = newSpline;
            if (listener != null) listener.onSplineChanged(newSpline);
            updateCheckboxes();
        }
    }

    public void handleClearClick(GButton source, GEvent event) {
        activeSpline.clear();
    }

    public void handleThinClick(GButton source, GEvent event) {
        activeSpline.setThickness(1.0f);
    }

    public void handleThickClick(GButton source, GEvent event) {
        activeSpline.setThickness(5.0f);
    }

    public void handleColorClick(GButton source, GEvent event) {
        int newColor = app.color(app.random(255), app.random(255), app.random(255));
        activeSpline.setColor(newColor);
    }

    public void handleTangentsToggle(GCheckbox source, GEvent event) {
        if (event == GEvent.CLICKED && activeSpline != null) {
            activeSpline.setShowTangents(source.isSelected());
        }
    }

    public boolean isTangentsShown() {
        return showTangentsCheckbox.isSelected();
    }

    public boolean isCurvatureShown() {
        return showCurvatureCheckbox.isSelected();
    }

    public void handleCurvatureToggle(GCheckbox source, GEvent event) {
        if (event == GEvent.CLICKED && activeSpline != null) {
            activeSpline.setShowCurvature(source.isSelected());
        }
    }

    public void resize(int newHeight) {
        this.height = newHeight;

        int padding = 10;
        int btnWidth = width - 2 * padding;
        int btnHeight = 40;
        int yPos = padding;

        splineSelector.moveTo(x + padding, yPos);
        yPos += btnHeight + 10;

        clearButton.moveTo(x + padding, yPos);
        yPos += btnHeight + 10;

        thinButton.moveTo(x + padding, yPos);
        yPos += btnHeight + 10;

        thickButton.moveTo(x + padding, yPos);
        yPos += btnHeight + 10;

        colorButton.moveTo(x + padding, yPos);
        yPos += btnHeight + 10;

        showTangentsCheckbox.moveTo(x + padding, yPos);
        yPos += 30;

        showCurvatureCheckbox.moveTo(x + padding, yPos);

        saveButton.moveTo(x + padding, yPos);
        yPos += btnHeight + 10;

        loadButton.moveTo(x + padding, yPos);
        yPos += btnHeight + 10;

    }

    private String selectOutputFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Сохранить точки в файл");
        chooser.setFileFilter(new FileNameExtensionFilter("Текстовые файлы", "txt"));
        int res = chooser.showSaveDialog(null);
        if (res == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".txt")) {
                file = new File(file.getParentFile(), file.getName() + ".txt");
            }
            return file.getAbsolutePath();
        }
        return null;
    }

    private String selectInputFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Выбрать файл с точками");
        chooser.setFileFilter(new FileNameExtensionFilter("Текстовые файлы", "txt"));
        int res = chooser.showOpenDialog(null);
        if (res == JFileChooser.APPROVE_OPTION) {
            return chooser.getSelectedFile().getAbsolutePath();
        }
        return null;
    }

    public void handleSaveClick(GButton source, GEvent event) {
        if (activeSpline != null) {
            // Предполагаем, что getPoints() возвращает List<PVector>
            String[] lines = activeSpline.getPoints().stream()
                    .map(p -> p.getPosition().x + " " + p.getPosition().y)
                    .toArray(String[]::new);


            String path = selectOutputFile();
            if (path != null) {
                app.saveStrings(path, lines);
            }
        }
    }

    public void handleLoadClick(GButton source, GEvent event) {
        String path = selectInputFile();
        if (path != null && activeSpline != null) {
            String[] lines = app.loadStrings(path);
            activeSpline.clear();
            for (String line : lines) {
                String[] tokens = line.trim().split("\\s+");
                if (tokens.length == 2) {
                    try {
                        float x = Float.parseFloat(tokens[0]);
                        float y = Float.parseFloat(tokens[1]);
                        activeSpline.addPoint(new PVector(x, y));
                    } catch (NumberFormatException ignored) {}
                }
            }
        }
    }

}
