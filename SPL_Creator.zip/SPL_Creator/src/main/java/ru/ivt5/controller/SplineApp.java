package ru.ivt5.controller;

import processing.core.PApplet;
import ru.ivt5.model.*;
import ru.ivt5.view.SplinePanel;
import ru.ivt5.view.UIControls;

public class SplineApp extends PApplet {

    private SplinePanel splinePanel;
    private UIControls uiControls;
    private int lastHeight = 0;  // отслеживание изменения высоты

    // Модели сплайнов
    private C0Spline c0Spline = new C0Spline();
    private C1Spline c1Spline = new C1Spline();
    private C2Spline c2Spline = new C2Spline();

    // Активный сплайн
    private Spline activeSpline = c0Spline;

    public static void main(String[] args) {
        PApplet.main(SplineApp.class.getName());
    }

    @Override
    public void settings() {
        size(1000, 800);
        smooth();
    }

    @Override
    public void setup() {
        surface.setTitle("Мини-САПР Сплайнов от Ивана");
        surface.setResizable(false);
        uiControls = new UIControls(this, 0, 0, 300, height);  // шире
        splinePanel = new SplinePanel(this, 300, 0, width - 300, height, uiControls);


        // Передаем модели сплайнов в элементы управления, чтобы можно было переключать активный сплайн
        uiControls.setSplines(c0Spline, c1Spline, c2Spline);
        uiControls.setActiveSpline(activeSpline);

        // Подписываемся на смену сплайна из UI
        uiControls.setSplineChangeListener(newSpline -> {
            activeSpline = newSpline;
            splinePanel.setActiveSpline(activeSpline);
        });

        splinePanel.setActiveSpline(activeSpline);

        lastHeight = height;
    }

    @Override
    public void draw() {
        if (height != lastHeight) {
            uiControls.resize(height);
            lastHeight = height;
        }

        background(200,220, 255); // темно-синий фон
        uiControls.draw();
        splinePanel.draw();
    }

    @Override
    public void mousePressed() {
        if (mouseX >= 250) {
            splinePanel.mousePressed();
        }
    }

    @Override
    public void mouseDragged() {
        if (mouseX >= 250) {
            splinePanel.mouseDragged();
        }
    }

    @Override
    public void mouseReleased() {
        if (mouseX >= 250) {
            splinePanel.mouseReleased();
        }
    }
}
