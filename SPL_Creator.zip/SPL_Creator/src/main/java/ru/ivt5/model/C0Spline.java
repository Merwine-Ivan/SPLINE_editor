package ru.ivt5.model;

import processing.core.PApplet;
import processing.core.PVector;

public class C0Spline extends Spline {

    @Override
    public void generateCurve(PApplet app) {
        curvePoints.clear(); // очищаем старую кривую

        if (points.size() < 2) return;

        for (int i = 0; i < points.size() - 1; i++) {
            PVector p1 = points.get(i).getPosition();
            PVector p2 = points.get(i + 1).getPosition();
            // Просто линейное соединение контрольных точек
            curvePoints.add(p1.copy());
            curvePoints.add(p2.copy());
        }
    }

    @Override
    public void drawTangents(PApplet app) {
        app.stroke(0xFFAA0000); // красный
        app.strokeWeight(1);
        for (int i = 0; i < curvePoints.size() - 1; i += 2) {
            PVector start = curvePoints.get(i);
            PVector end = curvePoints.get(i + 1);
            PVector mid = PVector.lerp(start, end, 0.5f);
            PVector tangent = PVector.sub(end, start).normalize().mult(20);
            app.line(mid.x, mid.y, mid.x + tangent.x, mid.y + tangent.y);
        }
    }

    @Override
    public void drawCurvature(PApplet app) {
        // Кривизна для линейных сегментов равна нулю — не отображаем
    }
}
