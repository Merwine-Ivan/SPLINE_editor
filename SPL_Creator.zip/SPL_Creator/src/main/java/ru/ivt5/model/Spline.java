package ru.ivt5.model;

import processing.core.PApplet;
import processing.core.PVector;

import java.util.ArrayList;
import java.util.List;

public abstract class Spline {
    protected List<Point> points = new ArrayList<>();
    protected List<PVector> curvePoints = new ArrayList<>();

    protected int color = 0xFF000000; // чёрный по умолчанию
    protected float thickness = 2.0f;

    private Point selectedPoint = null;
    private static final float SELECTION_RADIUS = 10.0f;

    // Новые флаги отображения
    protected boolean showTangents = false;
    protected boolean showCurvature = false;

    // Абстрактный метод — каждый тип сплайна реализует по-своему
    public abstract void generateCurve(PApplet app);

    // Универсальная отрисовка
    public final void draw(PApplet app) {
        generateCurve(app);
        drawCurve(app);
        drawControlPoints(app);

        if (showTangents) {
            drawTangents(app);
        }

        if (showCurvature) {
            drawCurvature(app);
        }
    }

    // Отрисовка кривой
    protected void drawCurve(PApplet app) {
        app.stroke(color);
        app.strokeWeight(thickness);
        app.noFill();

        if (curvePoints.size() < 2) return;

        app.beginShape();
        for (PVector p : curvePoints) {
            app.vertex(p.x, p.y);
        }
        app.endShape();
    }

    // Отрисовка контрольных точек
    protected void drawControlPoints(PApplet app) {
        app.fill(0);
        app.noStroke();
        for (Point p : points) {
            PVector pos = p.getPosition();
            app.ellipse(pos.x, pos.y, 8, 8);
        }
    }

    // Добавленные методы отображения (можно реализовать позже)
    public void drawTangents(PApplet app) {
        // По умолчанию ничего не делаем, переопределить в подклассах при необходимости
    }

    public void drawCurvature(PApplet app) {
        // По умолчанию ничего не делаем, переопределить в подклассах при необходимости
    }

    // Работа с точками
    public void addPoint(PVector position) {
        points.add(new Point(position));
    }

    public void removePoint(float x, float y) {
        points.removeIf(p -> p.getPosition().dist(new PVector(x, y)) < SELECTION_RADIUS);
    }

    public void clear() {
        points.clear();
        curvePoints.clear();
        selectedPoint = null;
    }

    public boolean hasSelectedPoint() {
        return selectedPoint != null;
    }

    public void selectPoint(float x, float y) {
        for (Point p : points) {
            if (p.getPosition().dist(new PVector(x, y)) < SELECTION_RADIUS) {
                selectedPoint = p;
                return;
            }
        }
    }

    public void dragSelectedPoint(float x, float y) {
        if (selectedPoint != null) {
            selectedPoint.setPosition(new PVector(x, y));
        }
    }

    public void releaseSelectedPoint() {
        selectedPoint = null;
    }

    // Настройки внешнего вида
    public void setColor(int c) {
        this.color = c;
    }

    public void setThickness(float t) {
        this.thickness = t;
    }

    // Переключатели отображения
    public void setShowTangents(boolean show) {
        this.showTangents = show;
    }

    public void setShowCurvature(boolean show) {
        this.showCurvature = show;
    }

    public boolean isShowTangents() {
        return showTangents;
    }

    public boolean isShowCurvature() {
        return showCurvature;
    }

    // Геттеры
    public List<Point> getPoints() {
        return points;
    }

    public List<PVector> getCurvePoints() {
        return curvePoints;
    }
}
