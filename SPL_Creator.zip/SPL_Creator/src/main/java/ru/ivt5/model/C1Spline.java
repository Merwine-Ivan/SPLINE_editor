package ru.ivt5.model;

import processing.core.PApplet;
import processing.core.PVector;

public class C1Spline extends Spline {

    @Override
    public void generateCurve(PApplet app) {
        curvePoints.clear();

        if (points.size() < 2) return;

        // Добавляем фиктивные точки
        PVector first = points.get(0).getPosition();
        PVector second = points.get(1).getPosition();
        PVector last = points.get(points.size() - 1).getPosition();
        PVector penultimate = points.get(points.size() - 2).getPosition();

        PVector preFirst = PVector.sub(first, PVector.sub(second, first));
        PVector postLast = PVector.sub(last, PVector.sub(penultimate, last));

        curvePoints.add(preFirst);
        for (Point p : points) {
            curvePoints.add(p.getPosition());
        }
        curvePoints.add(postLast);
    }

    @Override
    protected void drawCurve(PApplet app) {
        app.stroke(color);
        app.strokeWeight(thickness);
        app.noFill();

        if (curvePoints.size() < 4) return;

        app.beginShape();
        for (PVector p : curvePoints) {
            app.curveVertex(p.x, p.y);
        }
        app.endShape();
    }

    @Override
    public void drawTangents(PApplet app) {
        if (points.size() < 2) return;

        app.stroke(255, 0, 0);
        app.strokeWeight(2);

        for (int i = 1; i < points.size() - 1; i++) {
            PVector prev = points.get(i - 1).getPosition();
            PVector next = points.get(i + 1).getPosition();
            PVector current = points.get(i).getPosition();

            // Для C1 можно считать касательную как вектор между соседними опорными точками
            PVector tangent = PVector.sub(next, prev).normalize().mult(20);

            // Отрисовка касательной из текущей точки
            app.line(current.x, current.y, current.x + tangent.x, current.y + tangent.y);
        }

        // Граничные точки — аппроксимируем касательные отдельно
        if (points.size() >= 2) {
            // Начальная точка
            PVector first = points.get(0).getPosition();
            PVector second = points.get(1).getPosition();
            PVector tangentStart = PVector.sub(second, first).normalize().mult(20);
            app.line(first.x, first.y, first.x + tangentStart.x, first.y + tangentStart.y);

            // Конечная точка
            PVector last = points.get(points.size() - 1).getPosition();
            PVector beforeLast = points.get(points.size() - 2).getPosition();
            PVector tangentEnd = PVector.sub(last, beforeLast).normalize().mult(20);
            app.line(last.x, last.y, last.x + tangentEnd.x, last.y + tangentEnd.y);
        }
    }


    @Override
    public void drawCurvature(PApplet app) {
        // Можно вычислить кривизну через численные производные, но для C1 это редко делают, поэтому и я не буду)))
    }
}
