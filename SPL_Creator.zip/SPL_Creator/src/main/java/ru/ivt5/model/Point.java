package ru.ivt5.model;

import processing.core.PVector;

public class Point {

    private PVector position;

    public Point(float x, float y) {
        this.position = new PVector(x, y);
    }

    public Point(PVector position) {
        this.position = position.copy();  // копируем, чтобы не было внешних изменений
    }

    public PVector getPosition() {
        return position;
    }

    public void setPosition(PVector position) {
        this.position = position.copy();
    }

    public float getX() {
        return position.x;
    }

    public float getY() {
        return position.y;
    }

    public void setX(float x) {
        this.position.x = x;
    }

    public void setY(float y) {
        this.position.y = y;
    }

    public float distanceTo(Point other) {
        return PVector.dist(this.position, other.position);
    }
}
