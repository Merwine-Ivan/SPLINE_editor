package ru.ivt5.model;

import processing.core.PApplet;
import processing.core.PVector;

import java.util.ArrayList;
import java.util.List;

public class C2Spline extends Spline {

    private PVector[] ctrl1;
    private PVector[] ctrl2;

    @Override
    public void generateCurve(PApplet app) {
        int n = points.size();
        curvePoints.clear();
        if (n < 2) return;

        List<PVector> pts = new ArrayList<>();
        for (Point p : points) {
            pts.add(p.getPosition());
        }

        // Подготовка массивов управляющих точек
        ctrl1 = new PVector[n - 1];
        ctrl2 = new PVector[n - 1];

        // Решаем систему уравнений для координат X и Y отдельно
        float[] rhsX = new float[n];
        float[] rhsY = new float[n];

        // Начальные условия
        rhsX[0] = pts.get(0).x + 2 * pts.get(1).x;
        rhsY[0] = pts.get(0).y + 2 * pts.get(1).y;

        for (int i = 1; i < n - 1; i++) {
            rhsX[i] = 4 * pts.get(i).x + 2 * pts.get(i + 1).x;
            rhsY[i] = 4 * pts.get(i).y + 2 * pts.get(i + 1).y;
        }

        rhsX[n - 1] = (8 * pts.get(n - 1).x + pts.get(n - 2).x) / 2;
        rhsY[n - 1] = (8 * pts.get(n - 1).y + pts.get(n - 2).y) / 2;

        float[] xControl = solve(rhsX);
        float[] yControl = solve(rhsY);

        // Заполняем ctrl1
        for (int i = 0; i < n - 1; i++) {
            ctrl1[i] = new PVector(xControl[i], yControl[i]);
        }

        // Заполняем ctrl2
        for (int i = 0; i < n - 2; i++) {
            ctrl2[i] = new PVector(
                    2 * pts.get(i + 1).x - xControl[i + 1],
                    2 * pts.get(i + 1).y - yControl[i + 1]
            );
        }
        ctrl2[n - 2] = new PVector(
                (pts.get(n - 1).x + xControl[n - 2]) / 2,
                (pts.get(n - 1).y + yControl[n - 2]) / 2
        );

        // Отрисовка кривой
        app.stroke(color);
        app.strokeWeight(thickness);
        app.noFill();

        app.beginShape();
        app.vertex(pts.get(0).x, pts.get(0).y);
        for (int i = 0; i < n - 1; i++) {
            PVector c1 = ctrl1[i];
            PVector c2 = ctrl2[i];
            PVector p = pts.get(i + 1);

            // Сохраняем точки кривой
            for (float t = 0; t <= 1.0; t += 0.05f) {
                PVector pt = bezierPoint(pts.get(i), c1, c2, p, t);
                curvePoints.add(pt.copy());
            }

            app.bezierVertex(c1.x, c1.y, c2.x, c2.y, p.x, p.y);
        }
        app.endShape();
    }

    private float[] solve(float[] rhs) {
        int n = rhs.length;
        float[] x = new float[n];
        float[] tmp = new float[n];
        float b = 2.0f;
        x[0] = rhs[0] / b;

        for (int i = 1; i < n; i++) {
            tmp[i] = 1 / b;
            b = (i < n - 1) ? 4.0f - tmp[i] : 3.5f - tmp[i];
            x[i] = (rhs[i] - x[i - 1]) / b;
        }

        for (int i = n - 2; i >= 0; i--) {
            x[i] -= tmp[i + 1] * x[i + 1];
        }

        return x;
    }

    private PVector bezierPoint(PVector p0, PVector c1, PVector c2, PVector p1, float t) {
        float u = 1 - t;
        float tt = t * t;
        float uu = u * u;
        float uuu = uu * u;
        float ttt = tt * t;

        PVector p = p0.copy().mult(uuu);
        p.add(c1.copy().mult(3 * uu * t));
        p.add(c2.copy().mult(3 * u * tt));
        p.add(p1.copy().mult(ttt));
        return p;
    }

    @Override
    public void drawTangents(PApplet app) {
        if (ctrl1 == null || ctrl2 == null) return;

        app.stroke(255, 0, 0);
        app.strokeWeight(2);
        for (int i = 0; i < ctrl1.length; i++) {
            PVector p = points.get(i).getPosition();
            PVector tan = PVector.sub(ctrl1[i], p).normalize().mult(20);
            app.line(p.x, p.y, p.x + tan.x, p.y + tan.y);
        }
    }

    @Override
    public void drawCurvature(PApplet app) {
        if (ctrl1 == null || ctrl2 == null) return;

        app.stroke(0, 255, 0);  // зелёненький
        app.fill(0, 255, 0);

        for (int i = 0; i < ctrl1.length; i++) {
            PVector p0 = points.get(i).getPosition();
            PVector p1 = ctrl1[i];
            PVector p2 = ctrl2[i];
            PVector p3 = points.get(i + 1).getPosition();

            // Кривизна в точке p0 (наша точка)
            float t = 0f;  // если хочешь в середине дуги — поставь 0.5f

            PVector pointOnCurve = bezierPoint(p0, p1, p2, p3, t);
            PVector tangent = bezierTangent(p0, p1, p2, p3, t);
            PVector second = bezierSecondDerivative(p0, p1, p2, p3, t);

            float dx = tangent.x;
            float dy = tangent.y;
            float ddx = second.x;
            float ddy = second.y;

            float num = (float) Math.pow(dx * dx + dy * dy, 1.5);
            float denom = Math.abs(dx * ddy - dy * ddx);
            if (denom < 1e-5) continue;

            float radius = num / denom;

            // Центр по нормали от точки на кривой
            PVector normal = new PVector(-dy, dx).normalize();
            PVector center = PVector.add(pointOnCurve, PVector.mult(normal, radius));

            // Отрисовка радиуса
            app.stroke(0, 255, 0);
            app.line(pointOnCurve.x, pointOnCurve.y, center.x, center.y);

            // Отрисовка окружности
            app.noFill();
            app.ellipse(center.x, center.y, 2 * radius, 2 * radius);

            // Центр окружности
            app.fill(0, 255, 0);
            app.noStroke();
            app.ellipse(center.x, center.y, 5, 5); // маленькая точка в центре окружки
        }
    }


    private PVector bezierTangent(PVector p0, PVector c1, PVector c2, PVector p1, float t) {
        float u = 1 - t;
        return new PVector(
                3 * u * u * (c1.x - p0.x) + 6 * u * t * (c2.x - c1.x) + 3 * t * t * (p1.x - c2.x),
                3 * u * u * (c1.y - p0.y) + 6 * u * t * (c2.y - c1.y) + 3 * t * t * (p1.y - c2.y)
        );
    }

    private PVector bezierSecondDerivative(PVector p0, PVector c1, PVector c2, PVector p1, float t) {
        float u = 1 - t;
        return new PVector(
                6 * u * (c2.x - 2 * c1.x + p0.x) + 6 * t * (p1.x - 2 * c2.x + c1.x),
                6 * u * (c2.y - 2 * c1.y + p0.y) + 6 * t * (p1.y - 2 * c2.y + c1.y)
        );
    }

}
